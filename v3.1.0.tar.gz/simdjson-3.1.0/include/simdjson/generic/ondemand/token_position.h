namespace simdjson {
namespace SIMDJSON_IMPLEMENTATION {
namespace ondemand {

/** @private Position in the JSON buffer indexes */
using token_position = const uint32_t *;

} // namespace ondemand
} // namespace SIMDJSON_IMPLEMENTATION
} // namespace simdjson
